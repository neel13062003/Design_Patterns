public interface Account {
    public void withdraw();
    void getAccountNumber();
}
