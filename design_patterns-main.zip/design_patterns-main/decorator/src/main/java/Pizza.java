public interface Pizza {
    public String bake();
}
