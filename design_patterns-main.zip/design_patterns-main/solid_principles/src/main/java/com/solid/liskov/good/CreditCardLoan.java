package com.solid.liskov.good;

public class CreditCardLoan implements LoanPayment {
    @Override
    public void doPayment(int amount) {

    }

}
