package com.solid.liskov.good;

public class HomeLoan implements SecureLoan {
    @Override
    public void doPayment(int amount) {

    }

    @Override
    public void foreCloseLoan() {

    }

}
