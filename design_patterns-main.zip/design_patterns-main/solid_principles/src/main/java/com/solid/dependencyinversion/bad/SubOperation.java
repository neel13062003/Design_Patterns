package com.solid.dependencyinversion.bad;

/**
 * One more sub module for substration
 */
public class SubOperation {
    public int sub(int a, int b){
        return a-b;
    }
}
