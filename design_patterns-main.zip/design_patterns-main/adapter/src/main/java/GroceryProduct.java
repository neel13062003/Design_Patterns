public class GroceryProduct implements GroceryItem{
    @Override
    public String getName() {
        return null;
    }

    @Override
    public String getPrice() {
        return null;
    }

    @Override
    public String getStoreName() {
        return null;
    }
}
