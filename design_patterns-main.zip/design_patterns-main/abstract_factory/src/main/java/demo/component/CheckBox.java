package demo.component;

public interface CheckBox {
    void paint();
}
